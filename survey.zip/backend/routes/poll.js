const express = require('express')
const {
    getAllPoll,
    getOnePoll,
    createPoll,
    deletePoll,
    updatePoll
} = require('../controllers/pollControl')
const requireAuth = require('../middleware/requireAuth')
const router = express.Router()


// // pollRoutes
// // require auth for all poll routes
router.use(requireAuth)

// GET all poll
router.get('/', getAllPoll)

// GET a single poll
router.get('/:id', getOnePoll)

// POST a new poll
router.post('/', createPoll)
  
// DELETE a poll
router.delete('/:id', deletePoll)
  
// UPDATE a poll
router.patch('/:id', updatePoll)


module.exports = router

// const fs = require('fs').promises;
// const path = require('path');
// const dataFile = path.join(__dirname, 'data.json');